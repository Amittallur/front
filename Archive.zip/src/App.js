import React from 'react';
import LoginForm from './components/LoginForm/LoginForm'; // Adjust the import path based on your project structure

const App = () => {
  return (
    <div className="container">
      <div className="form-container">
        <LoginForm />
      </div>
    </div>
  );
};

export default App;
