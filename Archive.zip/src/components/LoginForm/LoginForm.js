import React, { useState } from 'react';
import './LoginForm.css'; // Make sure to adjust the file extension based on your setup

const LoginForm = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (event) => {
    event.preventDefault();

    // Add your login logic here, such as making an API request to your backend

    // Example:
    console.log('Submitting:', { username, password });

    // Reset the form fields after submission
    setUsername('');
    setPassword('');
  };

  return (
    <div className="container">
      <h2 className="container__title">IP Blocklist in Panorama</h2>
      <div className="form-container">
        <form className="form" onSubmit={handleSubmit}>
          <label className="label" htmlFor="username">
            Username:
          </label>
          <input
            className="input"
            type="text"
            id="username"
            name="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
          <br />
          <br />

          <label className="label" htmlFor="password">
            Password:
          </label>
          <input
            className="input"
            type="password"
            id="password"
            name="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <br />
          <br />

          <input className="submit-button" type="submit" value="Login" />
        </form>
      </div>
    </div>
  );
};

export default LoginForm;
